﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

namespace CombinationsWithoutDuplicates
{
    class Program
    {
        static void Main(string[] args)
        {
            string givenString = "WORKING";
            char[] a = givenString.ToCharArray();
            List<char> output = new List<char>();
            FindCombinations(a, output, 0);
        }

        public static void FindCombinations(char[] a, List<char> output, int start)
        {
            for(int i = start; i < a.Length; i++)
            {
                output.Add(a[i]);
                //print the string 
                string word = new string(output.ToArray());
                Console.Write(word);
                bool isWord = Dictionary.isEnglishWord(word);
                Console.Write(", {0}", isWord);
                Console.WriteLine();

                if (i < a.Length -1 )
                {
                    FindCombinations(a, output, i + 1);
                }
                output.Remove(output[output.Count - 1]);
            }
        }
    }

    class Dictionary
    {
        public static List<string> listWords = new List<string> { "KING", "RING", "ORG", "OR", "WING", "WIG", "WON", "WOK", "WORN", "WORKING", "OR", "ON", "OK", "KG" };
        public static bool isEnglishWord(string word)
        {
            if (listWords.Contains(word))
            {
                return true;
            }
            return false;
        }
    }
}
